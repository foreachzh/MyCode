﻿using System;
using System.Windows.Forms;
using MSScriptControl;



namespace GMail账号注册机
{
    using laofurj.com;

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }






        private void button1_Click(object sender, EventArgs e)
        {
            // MessageBoxForm.ShowWarning(url);
            string html_str = "";

            HttpHelper http = new HttpHelper();
            HttpItem item = new HttpItem()
            {
                Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
                //  Encoding = Encoding.UTF8, //编码格式（utf-8,gb2312,gbk）     可选项 默认类会自动识别
                UserAgent = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36",
                URL = "https://accounts.google.com/SignUp?service=mail&hl=zh-CN&continue=http%3A%2F%2Fmail.google.com%2Fmail%2F%3Fpc%3Dcarousel-about-zh-CN",
                IsToLower = false,
                Allowautoredirect = false,
                Method = "GET",
                Timeout = 30000
            };

            try
            {
                HttpResult result = http.GetHtml(item);
                html_str = result.Html;
                http = null;
                item = null;
                result = null;
            }
            catch (Exception e1)
            {
                html_str = "异常！！！" + e1.Message;
            }

            //document.bg   );

            string start = "document.bg";
            string end = ");";

            string start1 = "/* Anti-spam";
            string end1 = "()</script>";



            //JScriptEngine d = new JScriptEngine();
            //d.exec(Properties.Resources.JavaScript1);

            string jscode = Properties.Resources.test;
            jscode = jscode.Replace("$sayhello?$", start1 + MySubstring(html_str, start1, end1) + "()");

          //  jscode = jscode.Replace("$sayhello?$", Properties.Resources.String1);


            jscode = jscode.Replace("$documentBG$", start + StringHelper.MySubstring(html_str, start, end) + end);
         //   jscode = jscode.Replace("$documentBG$", Properties.Resources.String2);

          
            textBox1.Text = RunJS(jscode, "test1", null);


        }




        /// <summary>
        /// 使用 ScriptControlClass执行JS
        /// 使用微软官方组件Interop.MSScriptControl
        ///  当JS方法中无参数时,这时传递的为该方法名称.
        ///  不支持X64,还需要附带DLL
        /// </summary>
        /// <param name="JsCodeStr"></param>
        /// <param name="JSfunctionName"></param>
        /// <param name="JSfunctionArge"></param>
        /// <returns></returns>
        public string RunJS(string JsCodeStr, string JSfunctionName, string JSfunctionArge)
        {
            ScriptControlClass sc = new ScriptControlClass();//申明变量
            sc.UseSafeSubset = true;//允许执行不安全的代码
            sc.Language = "JScript"; //VBScript
            sc.AddCode(JsCodeStr);
            string str;

            if (string.IsNullOrEmpty(JSfunctionArge))
            {
                //  要执行的方法名,执行的参数 / 如果无参那么就写方法名
                str = sc.Run(JSfunctionName, new object[] { JSfunctionName + "()" }).ToString();

            }
            else
            {
                str = sc.Run(JSfunctionName, new object[] { JSfunctionArge }).ToString();

            }



            //sc = new ScriptControlClass();
            //sc.UseSafeSubset = true;
            //sc.Language = "JScript";
            //sc.AddCode(Properties.Resources.base64);
            //string newstr = sc.Run("parse", new object[] { str }).ToString();
            //string nstr = sc.Run("stringify", new object[] { str }).ToString();
            //parse
            //stringify
            return str;
        }



        /// <summary>
        /// 模块功能：步进的方式截取一段字符串
        /// 
        /// strat_str 可以是空字符或者NULL, 这时是从第一个字符串开始记数截取
        ///  Last_str 可以是空字符或者NULL, 这时字符串的的尾部为结束
        /// 从测试字符串的头和尾截取一段字符串,只是开始的一段！！！
        /// Substring 的使用例子, GetSubValue正则怀疑有问题 不能解决时用 一般不用
        /// </summary>
        /// <param name="Test_str"></param>
        /// <param name="StratStr"></param>
        /// <param name="EndStr"></param>
        /// <returns></returns>
        public static string MySubstring(string Test_str, string StratStr, string EndStr)
        {
            //int str_strat = Test_str.IndexOf(strat_str) + strat_str.Length;
            //int str_len = Test_str.LastIndexOf(Last_str) - str_strat;
            //return (Test_str.Substring(str_strat, str_len)).Trim();

            int 截取字符串的开始位置 = 0;
            if (string.IsNullOrEmpty(StratStr) == false)
            {
                截取字符串的开始位置 = Test_str.IndexOf(StratStr);
                if (截取字符串的开始位置 == -1)
                    return "";
            }
            else
            {
                StratStr = "";
            }




            截取字符串的开始位置 = 截取字符串的开始位置 + (StratStr).Length;

            int 截取字符串结束位置 = Test_str.Length;

            if (string.IsNullOrEmpty(EndStr) == false)
            {

                截取字符串结束位置 = Test_str.IndexOf(EndStr, 截取字符串的开始位置);
                if (截取字符串结束位置 == -1)
                    return "";
            }
            return Test_str.Substring(截取字符串的开始位置, 截取字符串结束位置 - 截取字符串的开始位置);
        }





        private void Form1_Load(object sender, EventArgs e)
        {

        }





























    }
}
