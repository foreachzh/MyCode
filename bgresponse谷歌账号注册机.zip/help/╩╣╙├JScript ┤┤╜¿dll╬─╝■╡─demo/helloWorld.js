package helloWorld{
	expando class Hello {
        function say() {
            var d = new Date();
            var n = Math.random();
            return 'Hello, \\ntoday is ' + d + '\\nand this is random - ' + n;
        }
    }
}
