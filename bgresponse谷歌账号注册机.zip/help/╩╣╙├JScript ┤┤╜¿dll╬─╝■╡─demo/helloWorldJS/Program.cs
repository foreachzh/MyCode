﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms; // this has a MessageBox class
using helloWorld;

namespace helloWorldJS
{
/**
 *
 * ━━━━━━神兽出没━━━━━━
 * 　　　┏┓　　　┏┓
 * 　　┏┛┻━━━┛┻┓
 * 　　┃　　　　　　　┃
 * 　　┃　　　━　　　┃
 * 　　┃　┳┛　┗┳　┃
 * 　　┃　　　　　　　┃
 * 　　┃　　　┻　　　┃
 * 　　┃　　　　　　　┃
 * 　　┗━┓　　　┏━┛Code is far away from bug with the animal protecting
 * 　　　　┃　　　┃    神兽保佑,代码无bug
 * 　　　　┃　　　┃
 * 　　　　┃　　　┗━━━┓
 * 　　　　┃　　　　　　　┣┓
 * 　　　　┃　　　　　　　┏┛
 * 　　　　┗┓┓┏━┳┓┏┛
 * 　　　　　┃┫┫　┃┫┫
 * 　　　　　┗┻┛　┗┻┛
 *
 * ━━━━━━感觉萌萌哒━━━━━━
 */
    class Program
    {
        static void Main(string[] args)
        {
            var h = new helloWorld.Hello();
            MessageBox.Show(
                    h.say(),
                    "Dude!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation
            );
        }
    }
}
