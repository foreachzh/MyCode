using Microsoft.JScript;
using Microsoft.JScript.Vsa;
using System;
using System.Collections;

using System.Runtime.CompilerServices;




namespace helloWorld
{
	[Expando]
	[Serializable]
	public class Hello : IEnumerable, INeedEngine
	{
		private SimpleHashtable expando table;



		[NonSerialized]
		private VsaEngine vsa Engine;



		public object this[string]
		{
			get
			{
				return this.get expando table()[key] ?? Missing.Value;
			}
			set
			{
				SimpleHashtable expr_01 = this.get expando table();
				if (value != Missing.Value)
				{
					expr_01[key] = value;
					return;
				}
				expr_01.Remove(key);
			}
		}
		static Hello()
		{
		}
		private void init()
		{
		}
		public virtual string say()
		{
			DateObject value = GlobalObject.Date.CreateInstance(new object[0]);
			double d = MathObject.random();
			return "Hello, \\ntoday is " + Microsoft.JScript.Convert.ToString(value, true) + "\\nand this is random - " + Microsoft.JScript.Convert.ToString(d);
		}
		public Hello()
		{
			this..init();
		}
		private SimpleHashtable get expando table()
		{
			if (this.expando table == null)
			{
				this.expando table = new SimpleHashtable(8u);
			}
			return this.expando table;
		}
		public static bool op_Delete(Hello hello, params object[] array)
		{
			hello.get expando table().Remove(array[array.Length - 1]);
			return true;
		}
		IEnumerator IEnumerable.get enumerator()
		{
			return this.get expando table().GetEnumerator();
		}
		VsaEngine INeedEngine.GetEngine()
		{
			if (this.vsa Engine == null)
			{
				this.vsa Engine = VsaEngine.CreateEngineWithType(typeof(Hello).TypeHandle);
			}
			return this.vsa Engine;
		}
		void INeedEngine.SetEngine(VsaEngine vsaEngine)
		{
			this.vsa Engine = vsaEngine;
		}




















	}


















    [CompilerGlobalScope]
    public class JScript 0 : GlobalScope
{
	public JScript 0(GlobalScope globalScope) : base(globalScope, globalScope.engine)
	{
	}
public object Global Code()
{
    Package.JScriptPackage("helloWorld", this.engine);
    return null;
}
}


}
