﻿
var window = window || {};
var document = document || {};


$sayhello?$

$documentBG$

function test1()
{
    var output;
    try
    {
        document.bg.invoke(function (response)
        {
            // document.getElementById('bgresponse').value = response;
           // alert("shitou debug bgresponse:" + response);
            output = response;

        });
    } catch (err) { }

    return output;
} 


